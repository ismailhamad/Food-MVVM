package com.example.assi1

 class person {
  var name:String=""
  var Number:Int=0
  var address:String=""
  constructor()
  constructor(name:String,Number:Int,address:String){
   this.name=name
   this.Number=Number
   this.address=address
  }
}