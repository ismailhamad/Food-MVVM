package com.example.assi1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.activity_addperson.*


class Addperson : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_addperson)
        val db = Firebase.firestore
        save.setOnClickListener {
            val name=Name.text.toString()
            val number=Number.text.toString()
            val address=addr.text.toString()
            val person=person(name,number.toInt(),address)
            SavePerson(person,db)
            val i=Intent(this,MainActivity::class.java)
            startActivity(i)
        }
    }

    private fun SavePerson(person: person, db: FirebaseFirestore) {
        db.collection("person").add(person).addOnSuccessListener { documentReference->

        }
    }

}